#!/usr/bin/env python3
import json
from pathlib import Path

input_data = json.loads(Path("data/input.json").read_text(encoding="utf-8"))
result = {
    "pair_index": input_data["pair_index"],
    "sum_squares": sum(value * value for value in input_data["values"]),
    "generated_at": "2025-01-01T00:00:00Z",
}
Path("outputs").mkdir(exist_ok=True)
Path("outputs/results.json").write_text(
    json.dumps(result, sort_keys=True, separators=(",", ":")) + "\n",
    encoding="utf-8",
)
